An example of mlx functionality. Run:

./demo1.sh

to see an example of how quasinets are created. python2 is required.

./demo2.sh 

to draw a graph of the qnet. python3 is required. Matplotlib is required on your python3.