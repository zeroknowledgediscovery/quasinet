===============
cynet
===============

.. image:: http://zed.uchicago.edu/logo/logozed1.png
   :height: 400px
   :scale: 50 %
   :alt: alternate text
   :align: center


.. class:: no-web no-pdf

:Info: 
:Author: ZeD@UChicago <zed.uchicago.edu>
:Description: 
